class Test_misplaced {

	public void pattern(JFrame f, Dimension d) {
		f.setPreferredSize(d);
		f.pack();
	}
}