package input;

import java.util.ArrayList;

public static class Test_qualifiedType {
    
    void m() {
        java.util.A.StringTokenizer tokenizer = new java.util.A.StringTokenizer("\n");
        System.out.println(tokenizer);
    }
}