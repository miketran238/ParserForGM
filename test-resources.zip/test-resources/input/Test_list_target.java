import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Test_list {
	public void target(List l, int i) {
		l.isEmpty();
			l.add(i);
	}

}