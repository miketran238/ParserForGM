import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Test_add {
	public void pattern() {
		add();
		add(new Test_add());
		add();
	}

}