package input;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

class Test_anonymous_class {

	public static void target(String[] args) {
		JFrame f = new JFrame("Main Window");
		// add components
		f.pack();
		f.setVisible(true);
	}
}