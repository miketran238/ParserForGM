import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Test_list {
	public void pattern(List l, int i) {
		if (l.isEmpty())
			l.add(i);
	}

}